﻿//Grading ID: R2221
//CIS 199-02
// Program 3 
// Due 04/01/2022
// The purpose of this lab is to create a gui that accepts inputs on flowers to receive an output of costs and discounts.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_3
{
    public partial class prgrm3 : Form
    {
        public prgrm3()
        {
            InitializeComponent();
        }

        private void prgrm3_Load(object sender, EventArgs e) // Load event handler
        {
         
        }

        private void calcButton_Click(object sender, EventArgs e) // calc button
        {
            // Arrays used in the GUI
            string[] garType = { "Premium", "Standard", "Discount" }; // garden type
            double[] ratePer = { 110, 100, 90 }; // rates
            int[] flowerNum = { 10001, 10002, 10003, 10004, 10005, 10006, 10007 }; // item nums
            double[] cost = { 7.87, 9.51, 10.73, 9.99, 11.99, 5.00, 4.58 }; // cost per flower
            int[] quant = {0, 6, 16, 21}; // valid quantities to discount
            double[] disFull = {0, 5, 10, 15 }; // discounts based on quantity

            
            int item; // item input
            int flowQuan; // quant input
            string gar; // string for garden type
            double garDis = 0; // used to factor discount
            double garAdj = 0; // used to factor in rate
            double row = 0; // used to factor in cost
            const double mag = 100; // const for 100
       

            // bool variables used for sequential search 
            bool flowerFound = false;
            bool gardenFound = false;
            bool qtyFound = false;



            // TryParse conditional statements to prevent incorrect input.
            if (int.TryParse(itemTxt.Text, out item) && item >= 10001 && item <= 10007)
                if (int.TryParse(quanTxt.Text, out flowQuan) &&  flowQuan >= 0)
                    if (gardCombo.SelectedIndex >= 0) // Conditional combobox 
                    {
                        for (int x = 0; x < flowerNum.Length && !flowerFound; ++x) // for loop used for comparing item numbers to flowerNum
                        {
                            if (item == flowerNum[x])
                            {
                                flowerFound = true; // flowerFound true
                                row = cost[x]; // assigns cost value to row
                            }
                        }
                            for(int y = 0; y < garType.Length && !gardenFound; ++y) // Loop statement for garden type
                        {
                            gar = gardCombo.Text; // setting combobox equal to string
                            if (gar == garType[y]) 
                            {
                                gardenFound = true; // gardenFound true
                                garAdj = ratePer[y]; // assigns rate value to garAdj

                            }
                        }
                                for (int z = quant.Length - 1; z >= 0 && !qtyFound; --z)//Loop used to compare quantity to quantity array with discount
                                {

                            if (flowQuan >= quant[z])
                            {
                                qtyFound = true; // qtyFound true
                                garDis = disFull[z]; // assigns discount to garDis

                            }

                                }

                                if (flowerFound && gardenFound && qtyFound) // output of in GUI
                                {
                               double totalRow = flowQuan * row; // total row cost
                                rowOut.Text = $"{totalRow:C}"; // row cost output

                              double totalAdj = (flowQuan * garAdj * row) / mag;// total base adj cost
                                 adjCostOut.Text = $"{totalAdj:C}"; // base adj cost output

                            disOut.Text = $"{garDis:F2}%"; // discount output

                            double totalCost = totalAdj -(totalAdj *garDis / mag); // total cost of flowers
                            totOut.Text = $"{totalCost:C2}";//totcost output


                                }

                    }
                    // These are messageboxes used when there is incorrect input.
                    else
                        MessageBox.Show("No Garden Type Selected"); 
                else
                    MessageBox.Show("Invalid Quantity");
            else
                MessageBox.Show("Invalid Item Number");
                   













        }
    }
}