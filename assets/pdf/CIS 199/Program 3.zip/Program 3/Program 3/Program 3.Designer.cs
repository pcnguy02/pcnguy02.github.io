﻿
namespace Program_3
{
    partial class prgrm3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gardInLbl = new System.Windows.Forms.Label();
            this.itemNmbr = new System.Windows.Forms.Label();
            this.QuanLbl = new System.Windows.Forms.Label();
            this.rowOutLbl = new System.Windows.Forms.Label();
            this.baseCost = new System.Windows.Forms.Label();
            this.disLbl = new System.Windows.Forms.Label();
            this.priceLbl = new System.Windows.Forms.Label();
            this.itemTxt = new System.Windows.Forms.TextBox();
            this.quanTxt = new System.Windows.Forms.TextBox();
            this.gardCombo = new System.Windows.Forms.ComboBox();
            this.calcButton = new System.Windows.Forms.Button();
            this.rowOut = new System.Windows.Forms.Label();
            this.adjCostOut = new System.Windows.Forms.Label();
            this.disOut = new System.Windows.Forms.Label();
            this.totOut = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // gardInLbl
            // 
            this.gardInLbl.AutoSize = true;
            this.gardInLbl.Location = new System.Drawing.Point(71, 46);
            this.gardInLbl.Name = "gardInLbl";
            this.gardInLbl.Size = new System.Drawing.Size(42, 13);
            this.gardInLbl.TabIndex = 0;
            this.gardInLbl.Text = "Garden";
            // 
            // itemNmbr
            // 
            this.itemNmbr.AutoSize = true;
            this.itemNmbr.Location = new System.Drawing.Point(10, 80);
            this.itemNmbr.Name = "itemNmbr";
            this.itemNmbr.Size = new System.Drawing.Size(103, 13);
            this.itemNmbr.TabIndex = 1;
            this.itemNmbr.Text = "Entree/Item Number";
            // 
            // QuanLbl
            // 
            this.QuanLbl.AutoSize = true;
            this.QuanLbl.Location = new System.Drawing.Point(67, 111);
            this.QuanLbl.Name = "QuanLbl";
            this.QuanLbl.Size = new System.Drawing.Size(46, 13);
            this.QuanLbl.TabIndex = 2;
            this.QuanLbl.Text = "Quantity";
            // 
            // rowOutLbl
            // 
            this.rowOutLbl.AutoSize = true;
            this.rowOutLbl.Location = new System.Drawing.Point(46, 209);
            this.rowOutLbl.Name = "rowOutLbl";
            this.rowOutLbl.Size = new System.Drawing.Size(67, 13);
            this.rowOutLbl.TabIndex = 3;
            this.rowOutLbl.Text = "Rowers Cost";
            // 
            // baseCost
            // 
            this.baseCost.AutoSize = true;
            this.baseCost.Location = new System.Drawing.Point(14, 243);
            this.baseCost.Name = "baseCost";
            this.baseCost.Size = new System.Drawing.Size(99, 13);
            this.baseCost.TabIndex = 4;
            this.baseCost.Text = "Base Adjusted Cost";
            // 
            // disLbl
            // 
            this.disLbl.AutoSize = true;
            this.disLbl.Location = new System.Drawing.Point(24, 271);
            this.disLbl.Name = "disLbl";
            this.disLbl.Size = new System.Drawing.Size(89, 13);
            this.disLbl.TabIndex = 5;
            this.disLbl.Text = "Discount Percent";
            // 
            // priceLbl
            // 
            this.priceLbl.AutoSize = true;
            this.priceLbl.Location = new System.Drawing.Point(55, 303);
            this.priceLbl.Name = "priceLbl";
            this.priceLbl.Size = new System.Drawing.Size(58, 13);
            this.priceLbl.TabIndex = 6;
            this.priceLbl.Text = "Total Price";
            // 
            // itemTxt
            // 
            this.itemTxt.Location = new System.Drawing.Point(119, 77);
            this.itemTxt.Name = "itemTxt";
            this.itemTxt.Size = new System.Drawing.Size(100, 20);
            this.itemTxt.TabIndex = 7;
            // 
            // quanTxt
            // 
            this.quanTxt.Location = new System.Drawing.Point(119, 108);
            this.quanTxt.Name = "quanTxt";
            this.quanTxt.Size = new System.Drawing.Size(100, 20);
            this.quanTxt.TabIndex = 8;
            // 
            // gardCombo
            // 
            this.gardCombo.FormattingEnabled = true;
            this.gardCombo.Items.AddRange(new object[] {
            "Premium",
            "Standard",
            "Discount"});
            this.gardCombo.Location = new System.Drawing.Point(119, 43);
            this.gardCombo.Name = "gardCombo";
            this.gardCombo.Size = new System.Drawing.Size(100, 21);
            this.gardCombo.TabIndex = 9;
            // 
            // calcButton
            // 
            this.calcButton.Location = new System.Drawing.Point(131, 164);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(75, 23);
            this.calcButton.TabIndex = 10;
            this.calcButton.Text = "Calculate";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
            // 
            // rowOut
            // 
            this.rowOut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rowOut.Location = new System.Drawing.Point(128, 209);
            this.rowOut.Name = "rowOut";
            this.rowOut.Size = new System.Drawing.Size(100, 20);
            this.rowOut.TabIndex = 11;
            // 
            // adjCostOut
            // 
            this.adjCostOut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.adjCostOut.Location = new System.Drawing.Point(128, 242);
            this.adjCostOut.Name = "adjCostOut";
            this.adjCostOut.Size = new System.Drawing.Size(100, 20);
            this.adjCostOut.TabIndex = 12;
            // 
            // disOut
            // 
            this.disOut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.disOut.Location = new System.Drawing.Point(128, 270);
            this.disOut.Name = "disOut";
            this.disOut.Size = new System.Drawing.Size(100, 20);
            this.disOut.TabIndex = 13;
            // 
            // totOut
            // 
            this.totOut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totOut.Location = new System.Drawing.Point(128, 302);
            this.totOut.Name = "totOut";
            this.totOut.Size = new System.Drawing.Size(100, 20);
            this.totOut.TabIndex = 14;
            // 
            // prgrm3
            // 
            this.AcceptButton = this.calcButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(287, 359);
            this.Controls.Add(this.totOut);
            this.Controls.Add(this.disOut);
            this.Controls.Add(this.adjCostOut);
            this.Controls.Add(this.rowOut);
            this.Controls.Add(this.calcButton);
            this.Controls.Add(this.gardCombo);
            this.Controls.Add(this.quanTxt);
            this.Controls.Add(this.itemTxt);
            this.Controls.Add(this.priceLbl);
            this.Controls.Add(this.disLbl);
            this.Controls.Add(this.baseCost);
            this.Controls.Add(this.rowOutLbl);
            this.Controls.Add(this.QuanLbl);
            this.Controls.Add(this.itemNmbr);
            this.Controls.Add(this.gardInLbl);
            this.Name = "prgrm3";
            this.Text = "Program 3";
            this.Load += new System.EventHandler(this.prgrm3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label gardInLbl;
        private System.Windows.Forms.Label itemNmbr;
        private System.Windows.Forms.Label QuanLbl;
        private System.Windows.Forms.Label rowOutLbl;
        private System.Windows.Forms.Label baseCost;
        private System.Windows.Forms.Label disLbl;
        private System.Windows.Forms.Label priceLbl;
        private System.Windows.Forms.TextBox itemTxt;
        private System.Windows.Forms.TextBox quanTxt;
        private System.Windows.Forms.ComboBox gardCombo;
        private System.Windows.Forms.Button calcButton;
        private System.Windows.Forms.Label rowOut;
        private System.Windows.Forms.Label adjCostOut;
        private System.Windows.Forms.Label disOut;
        private System.Windows.Forms.Label totOut;
    }
}

