﻿// class Superhero with one constructor of hero information using certain defaults with birthyear.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program4
{
    class Superhero
    {
        private const  int defYear = 1999; // default year
        private int _birthYear; // >= 0
        private bool _OnPlanetEarth; //earth status back field

        //Precondition: birthYear >=0 otherwise none.
        //Postcondition: birthYear is returned

        public Superhero(string heroName, string birthCity, string firstPower, int birthYear, string secondPower) // superhero constructor
        {
            //objects assigned to constructor 
            SuperheroName = heroName;
            BirthCity = birthCity;
            FirstSuperpower = firstPower;
            BirthYear = birthYear;
            SecondSuperpower = secondPower;
            
            
        }
        //Precondition: None
        //Postcondition: None
        public string SuperheroName { get; set; } 
        public char Initial // precondition initial = SuperheroName[0]
        {
            //Precondition: None
            //Postcondition: First initial has been returned
            get { return SuperheroName[0]; } 
        }
        //Precondition: None - BirthCity
        //Postcondition: None
        public string BirthCity { get; set; } // birth city prop

        //Precondition: None - first power
        //Postcondition: None
        public string FirstSuperpower { get; set; } // first power prop
        public int BirthYear // birthyear prop 
        {
            //Precondition: None
            //Postcondition: birth year is returend
            get
            {
                
                return _birthYear; // returned backfield
            }
            //Precondition: value >= 0
            //Postcondition: birth year is set to specific value
            set
            {
                
                if (value >= 0)
                {
                    _birthYear = value;
                }
                else
                {
                    _birthYear = defYear;
                }
            }

        }

        //Precondition: None - second power
        //Postcondition: None
        public string SecondSuperpower { get; set; }  // second power prop

        public void OnPlanetEarth() { _OnPlanetEarth = true; } // true planet earth stat method
        

        public void OffPlanetEarth() { _OnPlanetEarth = false; } //method for false earth stat
       

        public bool IsOnPlanetEarth() { return _OnPlanetEarth; } // bool earth stat method

        public override string ToString() // Output method 
        {
            string NL = Environment.NewLine; //new line
            //Returned print of heros
            return $"Name: { SuperheroName}{ NL}City: {BirthCity}{NL}First Super Power: {FirstSuperpower}{NL}" +
                $"Birth Year: {BirthYear}{NL}Second Super Power: {SecondSuperpower}{NL}" +
                $"Planet Earth: {IsOnPlanetEarth()}{NL}Initial: {Initial}{NL}"; 
        }

        

        
    }
}
    

