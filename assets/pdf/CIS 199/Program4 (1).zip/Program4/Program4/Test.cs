﻿//Grading ID: R2221
// CIS 199-02
//04/19/2022
//Program 4
// The purpose of this console it to create a list of objects. In this case, superheros. 
using static System.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program4
{
    class Test
    {
        static void Main()
        { 
            // List of super hero objects using Superhero Class
            Superhero superHero1 = new Superhero("Goku", "Planet Vegeta", "Kamehameha", 736, "Kaioken");

            Superhero superHero2 = new Superhero("Vegeta", "Planet Vegeta", "Galick Gun", 732, "Final Flash");
            Superhero superHero3 = new Superhero("Gohan", "West City", "Masenko", 757, "Hidden Potential");
            superHero3.OnPlanetEarth(); // setting earth status
            Superhero superHero4 = new Superhero("Piccolo", "West City", "Special Beam Cannon", 753, "Regeneration");
            superHero4.OnPlanetEarth();// setting earth status
            Superhero superHero5 = new Superhero("Dende", "Planet Namek", "Healing",757, "Magic Materialization");
            superHero5.OnPlanetEarth();// setting earth status

            Superhero[] SH = { superHero1, superHero2, superHero3, superHero4, superHero5 }; // array of each hero

            WriteLine("Original List of Super heros"); // orig hero writeline
            WriteLine("-----------------------------");
            PrintSH(SH); // original list print

            // Set of changes with superpowers/earth status
            superHero1.OnPlanetEarth(); 
            superHero1.SecondSuperpower = "Ultra Instinct";
            superHero2.OnPlanetEarth(); 
            superHero2.SecondSuperpower = "Super Saiyan Blue Evolved";
            superHero3.SecondSuperpower = "Super Saiyan 2";
            superHero4.SecondSuperpower = "Afterimage";
            superHero5.FirstSuperpower = "Telepathy";


            WriteLine("After changes"); // after change writeline
            WriteLine("--------------");
            PrintSH(SH); // prints list with changes from method

        }
        //Method to print the heros using a foreach loop
        public static void PrintSH(Superhero[] SH)
        {
            foreach (Superhero heros in SH) // foreach to cycle through the array w/o subscripts
            {
                WriteLine(heros.ToString()); // display of heros. 
            }
            
        }
    }
}
