﻿//Grading ID: R2221
//Program 1 
// 02/15/2022
// CIS 199-02
// The purpose of this program is to create an interactive application 
// that allows a user to receive information on the total costs of a shed.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program1
{
    class Program
    {
        static void Main(string[] args)
        {
            const double extraFactor = 1.1; // Extra factor
            const double windowFee = 100; // Window Cost
            double frontLength, sideLength, height; // Length input
            int windowNum; // Whether a window is stated
            double drywallCost; // Cost of drywall 
            double laborPerSqFt; // labor cost
            double totalSqft; // total sq feet
            double sqfeetExtra;// Used for total cost equation
            double laborCost, matCost, totalCost; // output of costs
           
            

            Console.WriteLine("Welcome to the Dry Wall and Window Installation Calculator"); //Title of Code

            Console.WriteLine(""); // line break

            Console.WriteLine("Enter the length of the front (in feet):"); // Input of front length
                 frontLength = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter the length of the Side(in feet):"); // Side length input
                 sideLength = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter the height (in feet):"); // height input
                 height = Convert.ToDouble(Console.ReadLine());

             Console.WriteLine("Enter 1 if you want a window, Enter 0 if you do not:"); // input for window
             windowNum = Convert.ToInt32(Console.ReadLine()); // window input

            

            Console.WriteLine("Enter cost of Dry Wall per square foot:"); // input drywall cost
                drywallCost = Convert.ToDouble(Console.ReadLine()); // cost for drywall

            Console.WriteLine("Enter cost of labor per square feet: "); // input cost of labor
                laborPerSqFt = Convert.ToDouble(Console.ReadLine()); // labor cost per sq ft

            Console.WriteLine(""); // line break

            totalSqft = ((frontLength * height) * 2) + ((sideLength * height) * 2) + (frontLength * sideLength); // total sqaure foot
            Console.WriteLine("Total SQ feet needed: {0:n2}", totalSqft); // output of total sq ft

            sqfeetExtra = totalSqft * extraFactor; // total sq ft with extra 10%
            Console.WriteLine("10% Extra Square Feet: {0:n2}", sqfeetExtra); // output of extra sq ft 

            laborCost = laborPerSqFt * sqfeetExtra; // labor cost formula
            Console.WriteLine("Labor Cost: {0:C}", laborCost); // output of labor cost

            matCost = drywallCost * sqfeetExtra; // material cost formula
            Console.WriteLine("Material Cost: {0:C}", matCost); // output of material cost

            totalCost = (laborCost + matCost) + (windowFee * windowNum); // total cost formula
            Console.WriteLine("Total Cost: {0:C}", totalCost); // output of total cost
             

            

            


            
            
                        
            



        }
    }
}
