﻿
namespace Program_2
{
    partial class ProgramTwo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.guestLbl = new System.Windows.Forms.Label();
            this.nightsLbl = new System.Windows.Forms.Label();
            this.starLbl = new System.Windows.Forms.Label();
            this.CostLbl = new System.Windows.Forms.Label();
            this.costOut = new System.Windows.Forms.Label();
            this.guestOut = new System.Windows.Forms.TextBox();
            this.nightOut = new System.Windows.Forms.TextBox();
            this.calcButton = new System.Windows.Forms.Button();
            this.starBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // guestLbl
            // 
            this.guestLbl.AutoSize = true;
            this.guestLbl.Location = new System.Drawing.Point(36, 44);
            this.guestLbl.Name = "guestLbl";
            this.guestLbl.Size = new System.Drawing.Size(95, 13);
            this.guestLbl.TabIndex = 0;
            this.guestLbl.Text = "Number of Guests:";
            // 
            // nightsLbl
            // 
            this.nightsLbl.AutoSize = true;
            this.nightsLbl.Location = new System.Drawing.Point(36, 69);
            this.nightsLbl.Name = "nightsLbl";
            this.nightsLbl.Size = new System.Drawing.Size(92, 13);
            this.nightsLbl.TabIndex = 1;
            this.nightsLbl.Text = "Number of Nights:";
            // 
            // starLbl
            // 
            this.starLbl.AutoSize = true;
            this.starLbl.Location = new System.Drawing.Point(36, 93);
            this.starLbl.Name = "starLbl";
            this.starLbl.Size = new System.Drawing.Size(62, 13);
            this.starLbl.TabIndex = 2;
            this.starLbl.Text = "Hotel Stars:";
            // 
            // CostLbl
            // 
            this.CostLbl.AutoSize = true;
            this.CostLbl.Location = new System.Drawing.Point(36, 185);
            this.CostLbl.Name = "CostLbl";
            this.CostLbl.Size = new System.Drawing.Size(59, 13);
            this.CostLbl.TabIndex = 3;
            this.CostLbl.Text = "Hotel Cost:";
            // 
            // costOut
            // 
            this.costOut.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.costOut.Location = new System.Drawing.Point(105, 185);
            this.costOut.Name = "costOut";
            this.costOut.Size = new System.Drawing.Size(100, 25);
            this.costOut.TabIndex = 4;
            // 
            // guestOut
            // 
            this.guestOut.Location = new System.Drawing.Point(140, 41);
            this.guestOut.Name = "guestOut";
            this.guestOut.Size = new System.Drawing.Size(100, 20);
            this.guestOut.TabIndex = 5;
            // 
            // nightOut
            // 
            this.nightOut.Location = new System.Drawing.Point(140, 66);
            this.nightOut.Name = "nightOut";
            this.nightOut.Size = new System.Drawing.Size(100, 20);
            this.nightOut.TabIndex = 6;
            // 
            // calcButton
            // 
            this.calcButton.Location = new System.Drawing.Point(65, 135);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(75, 23);
            this.calcButton.TabIndex = 8;
            this.calcButton.Text = "Calculate";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
            // 
            // starBox
            // 
            this.starBox.Location = new System.Drawing.Point(140, 93);
            this.starBox.Name = "starBox";
            this.starBox.Size = new System.Drawing.Size(100, 20);
            this.starBox.TabIndex = 9;
            // 
            // ProgramTwo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.starBox);
            this.Controls.Add(this.calcButton);
            this.Controls.Add(this.nightOut);
            this.Controls.Add(this.guestOut);
            this.Controls.Add(this.costOut);
            this.Controls.Add(this.CostLbl);
            this.Controls.Add(this.starLbl);
            this.Controls.Add(this.nightsLbl);
            this.Controls.Add(this.guestLbl);
            this.Name = "ProgramTwo";
            this.Text = "Program 2 ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label guestLbl;
        private System.Windows.Forms.Label nightsLbl;
        private System.Windows.Forms.Label starLbl;
        private System.Windows.Forms.Label CostLbl;
        private System.Windows.Forms.Label costOut;
        private System.Windows.Forms.TextBox guestOut;
        private System.Windows.Forms.TextBox nightOut;
        private System.Windows.Forms.Button calcButton;
        private System.Windows.Forms.TextBox starBox;
    }
}

