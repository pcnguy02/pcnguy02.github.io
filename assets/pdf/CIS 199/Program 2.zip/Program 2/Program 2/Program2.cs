﻿// Grading ID: R2221
// CIS 199-02
// Program 2
//03/11/2022
// The purpose of this program is to input and receive a cost of a hotel based on guests, number of nights, and number of stars. 
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_2
{
    public partial class ProgramTwo : Form
    {
        public ProgramTwo()
        {
            InitializeComponent();
        }

        private void calcButton_Click(object sender, EventArgs e) // Calculation button
        {
            double guest; // guest input
            double nights; // night input
            double flatFee; // flatfee
            double nightFee; // night fee
            double star; // input star
            double starFee; // star fee
            double total; // total equation
            



            guest = double.Parse(guestOut.Text); // input conversion - geust
            nights = double.Parse(nightOut.Text); // night input conversion
            star = double.Parse(starBox.Text); // star input conversion

            if (double.TryParse(guestOut.Text, out guest) && guest >= 1 && guest <= 7) // tryparse for guest
                if (double.TryParse(nightOut.Text, out nights) && nights >= 1) // tryparse for nights
                    if (double.TryParse(starBox.Text, out star) && star >= 1 && star <= 5) // tryparse for stars
                    {
                        { // guest if statement to determine flatfee.
                            if (guest == 1)
                                flatFee = 100;
                            else if (guest == 2)
                                flatFee = 150;
                            else if (guest == 3)
                                flatFee = 250;
                            else
                                flatFee = 400;
                        }

                        { // nights if statement to determine night fee.
                            if (nights >= 1 && nights <= 6)
                                nightFee = 100;
                            else if (nights >= 7 && nights <= 30)
                                nightFee = 75;
                            else
                                nightFee = 25;

                        }

                        { // star if statement to determine star fee.
                            if (star == 1)
                                starFee = 1;
                            else if (star == 2)
                                starFee = 1.5;
                            else if (star == 3)
                                starFee = 2.5;
                            else if (star == 4)
                                starFee = 3;
                            else
                                starFee = 4;

                        }




                        total = ((flatFee + nights * nightFee) * starFee); // total cost 

                    costOut.Text = $"{total:C}"; // total output

                    }

                    else
                        MessageBox.Show("Enter valid star rating"); // invalid star
                else
                    MessageBox.Show("Enter valid number of nights."); // invalid nights
            else
                MessageBox.Show("Enter valid number of guests"); // invalid guests

            



        }
    }
}
