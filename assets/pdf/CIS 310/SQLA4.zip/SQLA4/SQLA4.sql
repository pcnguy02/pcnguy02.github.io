--1. For every property, list the management office number, address, monthly rent, owner number, owner�s first name, and owner�s last name.

SELECT PROPERTY.OFFICE_NUM, PROPERTY.ADDRESS, PROPERTY.MONTHLY_RENT, OWNER.OWNER_NUM, OWNER.FIRST_NAME, OWNER.LAST_NAME
FROM PROPERTY INNER JOIN OWNER
ON PROPERTY.OWNER_NUM = OWNER.OWNER_NUM;

--2. For every completed or open service request, list the property ID, description, and status.

SELECT PROPERTY.PROPERTY_ID, SERVICE_REQUEST.DESCRIPTION, STATUS
FROM PROPERTY INNER JOIN SERVICE_REQUEST
ON PROPERTY.PROPERTY_ID = SERVICE_REQUEST.PROPERTY_ID
WHERE STATUS = 'Open' OR STATUS = 'Complete';

SELECT PROPERTY_ID, DESCRIPTION, STATUS
FROM SERVICE_REQUEST
WHERE STATUS LIKE '%Open%' OR STATUS = '%Complete%';

SELECT * FROM SERVICE_REQUEST;
--3. For every service request for furniture replacement, list the property ID, management office number, address, estimated hours, spent hours, owner number, and owner�s last name.

SELECT PROPERTY.PROPERTY_ID, OFFICE_NUM, PROPERTY.ADDRESS, 
SERVICE_REQUEST.EST_HOURS, SERVICE_REQUEST.SPENT_HOURS, 
OWNER.OWNER_NUM, OWNER.LAST_NAME
FROM PROPERTY INNER JOIN OWNER ON PROPERTY.OWNER_NUM = OWNER.OWNER_NUM
INNER JOIN SERVICE_REQUEST 
ON PROPERTY.PROPERTY_ID = SERVICE_REQUEST.PROPERTY_ID
WHERE CATEGORY_NUMBER = 6;

--4. List the first and last names of all owners who own a two-bedroom property. Use the IN operator in your query.

SELECT FIRST_NAME, LAST_NAME
FROM OWNER INNER JOIN PROPERTY
ON OWNER.OWNER_NUM = PROPERTY.OWNER_NUM
WHERE BDRMS IN(SELECT BDRMS
				FROM PROPERTY
					WHERE BDRMS = 2);
--5. Repeat Exercise 4, but this time use the EXISTS operator in your query.
SELECT FIRST_NAME, LAST_NAME
FROM OWNER
WHERE EXISTS(SELECT OWNER_NUM
				FROM PROPERTY
					WHERE PROPERTY.OWNER_NUM = OWNER.OWNER_NUM
						AND BDRMS = 2);


--6. List the property IDs of any pair of properties that have the same number of bedrooms. For example, one pair 
--would be property ID 2 and property ID 6, because they both have four bedrooms. 
--The first property ID listed should be the major 
--sort key and the second property ID should be the minor sort key.

SELECT PROPERTY_ID 
FROM PROPERTY
WHERE EXISTS (SELECT COUNT(*) FROM PROPERTY AS PROP_P
				WHERE PROP_P.BDRMS = PROPERTY.BDRMS
				GROUP BY BDRMS
				HAVING COUNT(*) = 2);


--7. List the square footage, owner number, owner last name, and owner first name for each property managed by the Columbia City office.

SELECT PROPERTY.SQR_FT, PROPERTY.OWNER_NUM, OWNER.LAST_NAME, OWNER.FIRST_NAME
FROM PROPERTY INNER JOIN OWNER ON PROPERTY.OWNER_NUM = OWNER.OWNER_NUM
INNER JOIN OFFICE ON PROPERTY.OFFICE_NUM = OFFICE.OFFICE_NUM
WHERE OFFICE_NAME = 'StayWell-Colombia City';


--8. Repeat Exercise 7, but this time include only those properties with three bedrooms.

SELECT PROPERTY.SQR_FT, PROPERTY.OWNER_NUM, OWNER.LAST_NAME, OWNER.FIRST_NAME
FROM PROPERTY INNER JOIN OWNER ON PROPERTY.OWNER_NUM = OWNER.OWNER_NUM
INNER JOIN OFFICE ON PROPERTY.OFFICE_NUM = OFFICE.OFFICE_NUM
WHERE OFFICE_NAME = 'StayWell-Colombia City' 
				AND BDRMS = 3;

--9. List the office number, address, and monthly rent for properties whose owners live in Washington state or own two-bedroom properties.

SELECT OFFICE_NUM, PROPERTY.ADDRESS, MONTHLY_RENT
FROM PROPERTY INNER JOIN OWNER ON PROPERTY.OWNER_NUM = OWNER.OWNER_NUM
WHERE STATE = 'WA' OR BDRMS = 2;

--10. List the office number, address, and monthly rent for properties whose owners live in Washington state and own a two-bedroom property.

SELECT OFFICE_NUM, PROPERTY.ADDRESS, MONTHLY_RENT
FROM PROPERTY INNER JOIN OWNER ON PROPERTY.OWNER_NUM = OWNER.OWNER_NUM
WHERE STATE = 'WA' AND BDRMS = 2;

--11. List the office number, address, and monthly rent for properties whose owners live in Washington state but do not own two-bedroom properties.

SELECT OFFICE_NUM, PROPERTY.ADDRESS, MONTHLY_RENT
FROM PROPERTY INNER JOIN OWNER ON PROPERTY.OWNER_NUM = OWNER.OWNER_NUM
WHERE STATE = 'WA' AND BDRMS <> 2

--12. Find the service ID and property ID for each service request whose estimated hours are greater than the number of estimated hours of at least one service request on which the category number is 5.

SELECT SERVICE_ID, PROPERTY_ID
FROM SERVICE_REQUEST
WHERE EST_HOURS > ANY(SELECT EST_HOURS FROM SERVICE_REQUEST
							WHERE CATEGORY_NUMBER = '5');
			

--13. Find the service ID and property ID for each service request whose estimated hours are greater than the number of estimated hours on every service request on which the category number is 5.

SELECT SERVICE_ID, PROPERTY_ID
FROM SERVICE_REQUEST
WHERE EST_HOURS > ALL(SELECT EST_HOURS FROM SERVICE_REQUEST
							WHERE CATEGORY_NUMBER = '5');

--14. List the address, square footage, owner number, service ID, number of estimated hours, and number of spent hours for each service request on which the category number is 4.

SELECT ADDRESS, SQR_FT, OWNER_NUM, SERVICE_REQUEST.SERVICE_ID, EST_HOURS, SPENT_HOURS
FROM PROPERTY INNER JOIN SERVICE_REQUEST ON PROPERTY.PROPERTY_ID = SERVICE_REQUEST.PROPERTY_ID
WHERE CATEGORY_NUMBER = 4;


--15. Repeat Exercise 14, but this time be sure each property is included regardless of whether the property currently has any service requests for category 4.

SELECT ADDRESS, SQR_FT, OWNER_NUM, SERVICE_REQUEST.SERVICE_ID, EST_HOURS, SPENT_HOURS
FROM PROPERTY LEFT JOIN SERVICE_REQUEST ON PROPERTY.PROPERTY_ID = SERVICE_REQUEST.PROPERTY_ID;



